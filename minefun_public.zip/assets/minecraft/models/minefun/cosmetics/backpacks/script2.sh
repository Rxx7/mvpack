#!/bin/bash
for file in $(find . -type f)
do
    echo "Checking $file"
    sed -i 's/"0": "item/"0": "item/item/g' $file
done
